# WISQL
EECS 647 WISQL Inventory System Project

WISQL is a web inventory system based on a SQL database back-end.  It can be accessed by going to:
  * http://people.eecs.ku.edu/~tsteiner/wisql/login.html
  
Project Engineers:
Michael Esry
Bill Kolega
Tyler Steiner